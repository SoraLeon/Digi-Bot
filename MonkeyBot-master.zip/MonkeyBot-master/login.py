#Token always has priority, if token is defined it will always attempt to login using a token
#Comment the token line or set it empty to use email login
# TEST
#token = 'MjkwMjI2MTc4NTcxMTA4MzU1.DERFfw.G0CN_X5HXGdFEtPyquyRzdEDa0M'
# BOT
token = 'Mjg5ODcyMjMxNTU4MDIxMTIy.DERFjw.Bew0JwJ3hDicJkOg4_hCpwLwEI4'
email = ''
password = ''
